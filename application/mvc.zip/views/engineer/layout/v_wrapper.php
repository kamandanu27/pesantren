<?php  
include 'v_head.php';
include 'v_nav.php';
include 'v_content.php';
include 'v_footer.php';
include 'v_copyright.php';
?>