<div class="footer">
  <div class="footer-inner">
    <div class="container">
      <div class="row">
        <div class="span12"> Copyright &copy; <a href="#">Ditek Jaya Indonesia 2020</a>. Allrights Reserved</div>
      </div>
    </div>
  </div>
</div>