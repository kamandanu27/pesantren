<?php 
	if ($ajax) 
	{
		$this->load->view($ajax);
	}
?>